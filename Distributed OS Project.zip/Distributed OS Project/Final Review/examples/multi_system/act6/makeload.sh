zip -9 src.zip app.py encoder.py morse.py
