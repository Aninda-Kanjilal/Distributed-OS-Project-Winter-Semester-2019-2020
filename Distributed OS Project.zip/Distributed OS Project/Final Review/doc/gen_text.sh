emacs -batch --load doc/settings.el --load doc/thespian.el --visit=$1 --funcall org-ascii-export-to-ascii
