"""This module contains messages that are exchanged between Actor
Systems or between the Admin and the individual Actor management."""

from thespian.actors import ActorSystemMessage
